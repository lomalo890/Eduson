peremennaya1 = int(input('a = ', ))    # запрашиваем первый коэффициент
VtorayaPeremennaya = int(input('b = ', ))    # запрашиваем второй коэффициент
c = int(input('c = ', ))    # запрашиваем третий коэффициент
if peremennaya1!= 0 and VtorayaPeremennaya % 2 == 0 and c!= 0:  # решение по сокращенной формуле, т.к. b - четное
    k = VtorayaPeremennaya / 2
    d1 = k ** 2 - peremennaya1 * c
    k1 = (-k + d1 ** 0.5) / peremennaya1
    k2 = (-k - d1 ** 0.5) / peremennaya1
print('так как коэффициент b - четное число, решаем по сокращенной формуле')
print(f'k1 = {k1}')
print(f'k2 = {k2}')  
if peremennaya1 != 0 and VtorayaPeremennaya % 2 != 0 and c != 0:     # решение полного уравнения
    d = VtorayaPeremennaya ** 2 - 4 * peremennaya1 * c
    if d > 0:
        k1 = (-VtorayaPeremennaya + d ** 0.5) / (2 * peremennaya1)
        print(f'дискриминант равен: {d}')
        print(f'первый корень равен: {round(k1, 2)}')
        k2 = (-VtorayaPeremennaya - d ** 0.5) / (2 * peremennaya1)
        print(f'второй корень равен: {round(k2, 2)}')  
    elif d < 0:
        print(f'так как дискриминант меньше нуля и равен: {d}')
        print('действительных корней нет') 
    else:
        k = -VtorayaPeremennaya / (2 * peremennaya1)
        print(f'уравнение имеет один корень: {k}')
        if peremennaya1 != 0 and c != 0 and VtorayaPeremennaya == 0:        # решение уравнения при b = 0
            if (- c / peremennaya1) >= 0:
                k1 = ( -c / peremennaya1 ) ** 0.5
                print(f'первый корень равен: {k1}')
                k2 = (-1) * (( -c / peremennaya1 ) ** 0.5)
                print(f'второй корень равен: {k2}')
        if ( - c / peremennaya1 ) < 0:
            print(f' -c / peremennaya1 = : {-c / peremennaya1}, т.е. < 0, поэтому действительных корней нет')
if peremennaya1 != 0 and c== 0 and VtorayaPeremennaya != 0:     # решение уравнения при с = 0
    print(f'корень уравнения равен либо нулю, либо {-VtorayaPeremennaya / peremennaya1}')
if peremennaya1 != 0 and VtorayaPeremennaya== 0 and c == 0:     # решение уравнения при b = 0 и c = 0 
    print(f'корни уравнения равны нулю, peremennaya1 * x ** 2 = 0')